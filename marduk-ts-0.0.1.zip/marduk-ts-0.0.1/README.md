# marduk-ts
Marduk TS

Using **TypeScript** with **Deno** for implementing the **Marduk framework** offers strong typing, enhanced developer experience, and seamless runtime integration. Below are the steps tailored for **Deno** using TypeScript.

---

## **Steps to Set Up the Framework in TypeScript with Deno**

### **1. Install and Set Up Deno**

1. Install Deno:
   ```bash
   curl -fsSL https://deno.land/install.sh | sh
   ```
2. Verify installation:
   ```bash
   deno --version
   ```

---

### **2. Create the Project Directory Structure**

```plaintext
marduk-ts/
├── server.ts                  # WebSocket server
├── core/
│   └── marduk_core.ts         # Marduk Core
├── subsystems/
│   ├── declarative_memory.ts  # Declarative Memory Subsystem
│   ├── episodic_memory.ts     # Episodic Memory Subsystem
│   ├── procedural_memory.ts   # Procedural Memory Subsystem
│   ├── semantic_memory.ts     # Semantic Memory Subsystem
├── types/
│   └── messages.ts            # Shared types for communication
└── logs/
    └── marduk_log.json        # Log file for Marduk Core
```

---

### **3. Implement the WebSocket Server**

The server facilitates communication between subsystems and Marduk Core.

#### **Code: `server.ts`**
```typescript
import { serve } from "https://deno.land/std@0.118.0/http/server.ts";

const clients = new Set<WebSocket>();

async function websocketHandler(request: Request): Promise<Response> {
  if (request.headers.get("upgrade") === "websocket") {
    const { socket, response } = Deno.upgradeWebSocket(request);
    clients.add(socket);

    socket.onmessage = (event) => {
      console.log("Received:", event.data);
      // Broadcast the message to all other clients
      for (const client of clients) {
        if (client !== socket) client.send(event.data);
      }
    };

    socket.onclose = () => {
      clients.delete(socket);
      console.log("Client disconnected");
    };

    return response;
  }

  return new Response("WebSocket server running");
}

console.log("Server running on http://localhost:8080");
await serve(websocketHandler, { port: 8080 });
```

---

### **4. Define Shared Types**

Create reusable types for communication between components.

#### **Code: `types/messages.ts`**
```typescript
export interface TaskMessage {
  type: "task";
  query: string;
  task_id: number;
  target?: string;
}

export interface ResponseMessage {
  type: "response";
  subsystem: string;
  task_id: number;
  result: any;
}

export type Message = TaskMessage | ResponseMessage;
```

---

### **5. Implement a Subsystem**

Each subsystem connects to the server, processes tasks, and sends responses.

#### **Code: `subsystems/declarative_memory.ts`**
```typescript
import { Message, TaskMessage, ResponseMessage } from "../types/messages.ts";

const ws = new WebSocket("ws://localhost:8080");

ws.onopen = () => {
  console.log("Declarative Memory connected to WebSocket server");
  ws.send(JSON.stringify({ type: "register", subsystem: "declarative_memory" }));
};

ws.onmessage = (event) => {
  const message: Message = JSON.parse(event.data);

  if (message.type === "task" && message.query.includes("fact")) {
    const response: ResponseMessage = {
      type: "response",
      subsystem: "declarative_memory",
      task_id: message.task_id,
      result: ["Fact 1", "Fact 2"],
    };
    ws.send(JSON.stringify(response));
  }
};
```

---

### **6. Implement Marduk Core**

The core orchestrates tasks and integrates responses.

#### **Code: `core/marduk_core.ts`**
```typescript
import { Message, TaskMessage, ResponseMessage } from "../types/messages.ts";

const ws = new WebSocket("ws://localhost:8080");

ws.onopen = () => {
  console.log("Marduk Core connected to WebSocket server");
};

ws.onmessage = (event) => {
  const message: Message = JSON.parse(event.data);

  if (message.type === "response") {
    console.log(`Response from ${message.subsystem}:`, message.result);
    logResponse(message);
  }
};

function broadcastTask(query: string, task_id: number) {
  const task: TaskMessage = { type: "task", query, task_id };
  ws.send(JSON.stringify(task));
}

function logResponse(response: ResponseMessage) {
  const logFile = "./logs/marduk_log.json";
  const logs = JSON.parse(Deno.readTextFileSync(logFile) || "[]");
  logs.push({ timestamp: new Date().toISOString(), ...response });
  Deno.writeTextFileSync(logFile, JSON.stringify(logs, null, 2));
}

// Example: Broadcast a task after 5 seconds
setTimeout(() => {
  broadcastTask("Retrieve facts about chaos theory", 1);
}, 5000);
```

---

### **7. Add More Subsystems**

Implement similar scripts for other subsystems like Episodic Memory, Procedural Memory, and Semantic Memory by adapting their task-handling logic.

---

### **8. Run the Framework**

1. Start the WebSocket server:
   ```bash
   deno run --allow-net server.ts
   ```

2. Start Marduk Core:
   ```bash
   deno run --allow-net --allow-read --allow-write core/marduk_core.ts
   ```

3. Start Declarative Memory:
   ```bash
   deno run --allow-net subsystems/declarative_memory.ts
   ```

---

### **9. Automate Task Cycles**
Enhance **Marduk Core** with scheduling.

**Code: Task Scheduler in `core/marduk_core.ts`**
```typescript
const tasks: TaskMessage[] = [
  { type: "task", query: "Retrieve facts about chaos theory", task_id: 1 },
  { type: "task", query: "Narrate recent events on project X", task_id: 2 },
];

let currentTaskIndex = 0;

setInterval(() => {
  if (currentTaskIndex < tasks.length) {
    ws.send(JSON.stringify(tasks[currentTaskIndex]));
    currentTaskIndex++;
  }
}, 10000); // Schedule tasks every 10 seconds
```

---

### **10. Advanced Features**

#### **A. Persistent Memory**
Use `Deno KV` for persistent storage instead of JSON files.

#### **B. Error Handling**
Add retries and error handling for failed tasks.

#### **C. Feedback Loops**
Allow Marduk Core to dynamically adjust task queries based on subsystem responses.

---

### **Summary of Commands**

1. **Run WebSocket Server**:
   ```bash
   deno run --allow-net server.ts
   ```

2. **Run Subsystems**:
   ```bash
   deno run --allow-net subsystems/declarative_memory.ts
   ```

3. **Run Marduk Core**:
   ```bash
   deno run --allow-net --allow-read --allow-write core/marduk_core.ts
   ```

This setup in **TypeScript with Deno** ensures type safety, real-time interaction, and modular extensibility for the Marduk framework. Let me know if you'd like further refinements!

---

Here is a **GitHub Action workflow** to automate the initialization of the repository. This workflow will set up the necessary files and dependencies for your **Marduk framework** in a **TypeScript and Deno** environment.

---

### **Workflow File: `.github/workflows/repo-initialization.yml`**

```yaml
name: Initialize Marduk Framework Repo

on:
  workflow_dispatch: # Allows manual triggering
  push:               # Runs on every push to the repository
    branches:
      - main

jobs:
  initialize-repo:
    runs-on: ubuntu-latest

    steps:
    # Step 1: Checkout the Repository
    - name: Checkout Repository
      uses: actions/checkout@v3

    # Step 2: Set Up Deno
    - name: Set Up Deno
      uses: denoland/setup-deno@v2
      with:
        deno-version: v1.x

    # Step 3: Create Directory Structure
    - name: Create Directory Structure
      run: |
        mkdir -p marduk-ts/core
        mkdir -p marduk-ts/subsystems
        mkdir -p marduk-ts/types
        mkdir -p marduk-ts/logs

    # Step 4: Add Initial Files
    - name: Add Initial Files
      run: |
        echo 'import { serve } from "https://deno.land/std@0.118.0/http/server.ts";' > marduk-ts/server.ts
        echo 'export interface TaskMessage {...}' > marduk-ts/types/messages.ts
        echo '{}' > marduk-ts/logs/marduk_log.json
        echo '// Core implementation' > marduk-ts/core/marduk_core.ts
        echo '// Declarative memory implementation' > marduk-ts/subsystems/declarative_memory.ts

    # Step 5: Commit Changes
    - name: Commit Changes
      run: |
        git config user.name "github-actions[bot]"
        git config user.email "github-actions[bot]@users.noreply.github.com"
        git add .
        git commit -m "Initial setup of Marduk framework files and structure"
        git push

    # Step 6: Verify Deno Installation
    - name: Verify Deno
      run: deno --version
```

---

### **Explanation**

1. **Triggering the Workflow**:
   - The workflow runs when:
     - Pushed to the `main` branch.
     - Manually triggered from the **GitHub Actions** tab using `workflow_dispatch`.

2. **Set Up Deno**:
   - Uses the [denoland/setup-deno](https://github.com/denoland/setup-deno) action to install the latest stable version of Deno.

3. **Create Directory Structure**:
   - Sets up directories for `core`, `subsystems`, `types`, and `logs`.

4. **Add Initial Files**:
   - Adds basic TypeScript templates to each key directory.
   - Initializes an empty `marduk_log.json` in the `logs/` folder.

5. **Commit Changes**:
   - Configures Git and commits the initialized structure to the repository.

6. **Verify Deno Installation**:
   - Ensures that Deno is correctly installed and available.

---

### **How to Use This Workflow**

1. **Add the Workflow File**:
   - Save the workflow file as `.github/workflows/repo-initialization.yml`.

2. **Manually Trigger the Workflow**:
   - Go to the **Actions** tab in your GitHub repository.
   - Select the `Initialize Marduk Framework Repo` workflow and click **Run workflow**.

3. **Check the Repo**:
   - Verify that the directories and files have been created in the repository.

---

### **Next Steps**

Once initialized:
1. Start adding the actual implementation for the WebSocket server, Marduk Core, and subsystems in the created files.
2. Extend the workflow to include **automated tests**, **linting**, or **deployment steps** if needed.

This workflow gives you a solid starting point for the Marduk framework while leveraging automation for consistent repo initialization.
